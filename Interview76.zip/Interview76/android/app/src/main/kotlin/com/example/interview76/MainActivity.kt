package com.example.interview76

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
